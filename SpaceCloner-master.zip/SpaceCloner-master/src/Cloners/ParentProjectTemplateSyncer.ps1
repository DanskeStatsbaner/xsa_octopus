function Sync-OctopusMasterOctopusProjectWithChildProjects
{
    param(
        $SourceData,
        $DestinationData,
        $CloneScriptOptions
    )  

 
    if ([string]::IsNullOrWhiteSpace($CloneScriptOptions.ParentProjectName) -eq $true -or [string]::IsNullOrWhiteSpace($CloneScriptOptions.ChildProjectsToSync) -eq $true)
    {
        Write-OctopusWarning "The template project parameter or the clone project parameter wasn't specified skipping the sync child projects process"
        return
    }


    $filteredSourceList = Get-OctopusFilteredList -itemList $sourceData.ProjectList -itemType "Projects" -filters $cloneScriptOptions.ParentProjectName

    $flength = 0
    
    foreach($SourceDataElement in $filteredSourceList)
    {
      $flength++
    }
    

    if ($flength -ne 1)
    {
        Throw "The project you specified as the template $($CloneScriptOptions.ParentProjectName) resulted in $($filteredList.Length) item(s) found in the source.  This count must be exactly equal to 1.  Please update the filter."
    }

    $sourceProject = $filteredSourceList[0]

    $filteredDestinationList = Get-OctopusFilteredList -itemList $DestinationData.ProjectList -itemType "Projects" -filters $cloneScriptOptions.ChildProjectsToSync

    $flength = 0
    
    foreach($DataElement in $filteredDestinationList)
    {
      $flength++
    }
    
    if ($flength -eq 0)
    {
        $header = @{ "X-Octopus-ApiKey" = $DestinationOctopusApiKey }

        # Create project json payload
        $jsonPayload = @{
                            Name = $CloneScriptOptions.ChildProjectsToSync
                            Description = $CloneScriptOptions.ChildProjectsToSync
                            ProjectGroupId = $SourceDataElement.ProjectGroupId
                            LifeCycleId = $SourceDataElement.LifecycleId
                        }

        # Create project
        Invoke-RestMethod -Method Post -Uri "$DestinationOctopusUrl/api/$($SourceDataElement.SpaceId)/projects" -Body ($jsonPayload | ConvertTo-Json -Depth 10) -Headers $header

        $destinationData = Get-OctopusData -octopusUrl $DestinationOctopusUrl -octopusApiKey $DestinationOctopusApiKey -spaceName $DestinationSpaceName
        $filteredDestinationList = Get-OctopusFilteredList -itemList $DestinationData.ProjectList -itemType "Projects" -filters $cloneScriptOptions.ChildProjectsToSync
    } 

    foreach($destinationProject in $filteredDestinationList)
    { 
        $sourceChannels = Get-OctopusProjectChannelList -project $sourceproject -OctopusData $sourceData
        $destinationChannels = Get-OctopusProjectChannelList -project $destinationProject -OctopusData $DestinationData

        Copy-OctopusProjectDeploymentProcess -sourceChannelList $sourceChannels -sourceProject $sourceProject -destinationChannelList $destinationChannels -destinationProject $destinationProject -sourceData $SourceData -destinationData $DestinationData 

        if ($CloneScriptOptions.CloneProjectRunbooks -eq $true)
        {
            Copy-OctopusProjectRunbooks -sourceChannelList $sourceChannels -destinationChannelList $destinationChannels -destinationProject $destinationProject -sourceProject $sourceProject -destinationData $DestinationData -sourceData $SourceData            
        }

        Copy-OctopusProjectVariables -sourceChannelList $sourceChannels -destinationChannelList $destinationChannels -destinationProject $destinationProject -sourceProject $sourceProject -destinationData $DestinationData -sourceData $SourceData -cloneScriptOptions $CloneScriptOptions -createdNewProject $createdNewProject        
    }
}